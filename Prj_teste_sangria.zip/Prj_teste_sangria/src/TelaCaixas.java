import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

public class TelaCaixas extends JFrame {

    private int idFun;
    private String nomeFuncionario;
    private String cargo;
    private Integer idSupervisor;

    private JLabel lblFuncionario;
    private JLabel lblCaixa;

    private JComboBox<String> cmbCaixas;

    private JButton btnAbrir;

    private ArrayList<Integer> idsCaixas =
            new ArrayList<>();


    public TelaCaixas(
            int idFun,
            String nomeFuncionario,
            String cargo,
            Integer idSupervisor
    ) {

        this.idFun = idFun;
        this.nomeFuncionario = nomeFuncionario;
        this.cargo = cargo;
        this.idSupervisor = idSupervisor;


        setTitle("Escolher Caixa");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        criarComponentes();
        carregarCaixas();
        criarEventos();

        setVisible(true);
    }


    private void criarComponentes() {

        lblFuncionario =
                new JLabel(
                        "Funcionario: "
                                + nomeFuncionario
                                + " - "
                                + cargo
                );

        lblFuncionario.setBounds(
                30, 30, 350, 25
        );

        add(lblFuncionario);


        lblCaixa =
                new JLabel("Escolha o Caixa:");

        lblCaixa.setBounds(
                30, 90, 120, 25
        );

        add(lblCaixa);


        cmbCaixas =
                new JComboBox<>();

        cmbCaixas.setBounds(
                160, 90, 180, 25
        );

        add(cmbCaixas);


        btnAbrir =
                new JButton("Abrir Caixa");

        btnAbrir.setBounds(
                140, 160, 150, 30
        );

        add(btnAbrir);
    }


    private void carregarCaixas() {

        String sql =
                "{CALL PROC_CONS_CAIXA()}";

        try (
                Connection conexao =
                        Conexao.conectar();

                CallableStatement comando =
                        conexao.prepareCall(sql);

                ResultSet resultado =
                        comando.executeQuery()
        ) {

            cmbCaixas.removeAllItems();
            idsCaixas.clear();


            while (resultado.next()) {

                int idCaixa =
                        resultado.getInt("id_caixa");

                String nomeCaixa =
                        resultado.getString("nome_caixa");


                idsCaixas.add(idCaixa);

                cmbCaixas.addItem(nomeCaixa);
            }

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(
                    null,
                    "Erro ao consultar caixas: "
                            + erro.getMessage()
            );
        }
    }


    private void criarEventos() {

        btnAbrir.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                int posicao =
                        cmbCaixas.getSelectedIndex();

                if (posicao == -1) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Nenhum caixa disponivel."
                    );

                    return;
                }


                int idCaixa =
                        idsCaixas.get(posicao);

                String nomeCaixa =
                        cmbCaixas
                                .getSelectedItem()
                                .toString();


                new TelaSangria(
                        idFun,
                        nomeFuncionario,
                        idSupervisor,
                        idCaixa,
                        nomeCaixa
                );

                dispose();
            }
        });
    }
}