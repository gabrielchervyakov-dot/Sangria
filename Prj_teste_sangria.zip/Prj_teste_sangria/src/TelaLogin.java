import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TelaLogin extends JFrame {

    private JLabel lblUsuario;
    private JLabel lblSenha;

    private JTextField txtUsuario;
    private JPasswordField txtSenha;

    private JButton btnEntrar;

    public TelaLogin() {

        setTitle("Login");
        setSize(400, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        criarComponentes();
        criarEventos();

        setVisible(true);
    }

    private void criarComponentes() {

        lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(50, 50, 100, 25);
        add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(150, 50, 170, 25);
        add(txtUsuario);


        lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(50, 100, 100, 25);
        add(lblSenha);

        txtSenha = new JPasswordField();
        txtSenha.setBounds(150, 100, 170, 25);
        add(txtSenha);


        btnEntrar = new JButton("Entrar");
        btnEntrar.setBounds(130, 160, 120, 30);
        add(btnEntrar);
    }

    private void criarEventos() {

        btnEntrar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                String usuario = txtUsuario.getText();

                String senha =
                        new String(txtSenha.getPassword());

                String sql =
                        "{CALL PROC_CONS_FUNCIONARIO(?, ?)}";

                try (
                        Connection conexao =
                                Conexao.conectar();

                        CallableStatement comando =
                                conexao.prepareCall(sql)
                ) {

                    comando.setString(1, usuario);
                    comando.setString(2, senha);

                    ResultSet resultado =
                            comando.executeQuery();

                    if (resultado.next()) {

                        int idFun =
                                resultado.getInt("id_fun");

                        String nome =
                                resultado.getString("nome");

                        String cargo =
                                resultado.getString("cargo");


                        Object supervisor =
                                resultado.getObject("id_supervisor");

                        Integer idSupervisor = null;

                        if (supervisor != null) {

                            idSupervisor =
                                    ((Number) supervisor).intValue();
                        }


                        JOptionPane.showMessageDialog(
                                null,
                                "Login realizado!\nFuncionario: "
                                        + nome
                        );


                        new TelaCaixas(
                                idFun,
                                nome,
                                cargo,
                                idSupervisor
                        );

                        dispose();

                    } else {

                        JOptionPane.showMessageDialog(
                                null,
                                "Usuario ou senha incorretos."
                        );
                    }

                    resultado.close();

                } catch (SQLException erro) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Erro no login: "
                                    + erro.getMessage()
                    );
                }
            }
        });
    }
}