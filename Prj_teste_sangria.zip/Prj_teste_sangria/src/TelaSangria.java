import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class TelaSangria extends JFrame {

    private int idFun;
    private String nomeFuncionario;

    private Integer idSupervisor;

    private int idCaixa;
    private String nomeCaixa;


    private JLabel lblFuncionario;
    private JLabel lblSupervisor;
    private JLabel lblCaixa;

    private JLabel lblIdSangria;
    private JLabel lblDinheiro;
    private JLabel lblSangria;
    private JLabel lblDinAtual;


    private JTextField txtIdSangria;
    private JTextField txtDinheiro;
    private JTextField txtSangria;
    private JTextField txtDinAtual;


    private JButton btnInserir;
    private JButton btnConsultar;
    private JButton btnAlterar;
    private JButton btnRemover;


    public TelaSangria(
            int idFun,
            String nomeFuncionario,
            Integer idSupervisor,
            int idCaixa,
            String nomeCaixa
    ) {

        this.idFun = idFun;
        this.nomeFuncionario = nomeFuncionario;
        this.idSupervisor = idSupervisor;

        this.idCaixa = idCaixa;
        this.nomeCaixa = nomeCaixa;


        setTitle("Sangria");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);


        criarComponentes();
        criarEventos();


        setVisible(true);
    }


    private void criarComponentes() {

        lblFuncionario =
                new JLabel(
                        "Funcionario: "
                                + nomeFuncionario
                                + " (ID "
                                + idFun
                                + ")"
                );

        lblFuncionario.setBounds(
                30, 20, 400, 25
        );

        add(lblFuncionario);


        lblSupervisor =
                new JLabel(
                        "ID Supervisor: "
                                + idSupervisor
                );

        lblSupervisor.setBounds(
                30, 50, 300, 25
        );

        add(lblSupervisor);


        lblCaixa =
                new JLabel(
                        "Caixa: "
                                + nomeCaixa
                                + " (ID "
                                + idCaixa
                                + ")"
                );

        lblCaixa.setBounds(
                30, 80, 300, 25
        );

        add(lblCaixa);


        lblIdSangria =
                new JLabel("ID Sangria:");

        lblIdSangria.setBounds(
                30, 140, 120, 25
        );

        add(lblIdSangria);


        txtIdSangria =
                new JTextField();

        txtIdSangria.setBounds(
                160, 140, 150, 25
        );

        add(txtIdSangria);


        lblDinheiro =
                new JLabel("Dinheiro:");

        lblDinheiro.setBounds(
                30, 180, 120, 25
        );

        add(lblDinheiro);


        txtDinheiro =
                new JTextField();

        txtDinheiro.setBounds(
                160, 180, 150, 25
        );

        add(txtDinheiro);


        lblSangria =
                new JLabel("Sangria:");

        lblSangria.setBounds(
                30, 220, 120, 25
        );

        add(lblSangria);


        txtSangria =
                new JTextField();

        txtSangria.setBounds(
                160, 220, 150, 25
        );

        add(txtSangria);


        lblDinAtual =
                new JLabel("Dinheiro Atual:");

        lblDinAtual.setBounds(
                30, 260, 120, 25
        );

        add(lblDinAtual);


        txtDinAtual =
                new JTextField();

        txtDinAtual.setBounds(
                160, 260, 150, 25
        );

        txtDinAtual.setEditable(false);

        add(txtDinAtual);


        btnInserir =
                new JButton("Inserir");

        btnInserir.setBounds(
                30, 330, 120, 30
        );

        add(btnInserir);


        btnConsultar =
                new JButton("Consultar");

        btnConsultar.setBounds(
                160, 330, 120, 30
        );

        add(btnConsultar);


        btnAlterar =
                new JButton("Alterar");

        btnAlterar.setBounds(
                290, 330, 120, 30
        );

        add(btnAlterar);


        btnRemover =
                new JButton("Remover");

        btnRemover.setBounds(
                420, 330, 120, 30
        );

        add(btnRemover);
    }


    private BigDecimal lerValor(
            JTextField campo
    ) {

        return new BigDecimal(
                campo
                        .getText()
                        .trim()
                        .replace(",", ".")
        );
    }


    private void criarEventos() {


        // ===============================
        // INSERIR
        // ===============================

        btnInserir.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent evento
                    ) {

                        if (idSupervisor == null) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Este funcionario nao possui supervisor."
                            );

                            return;
                        }


                        String sql =
                                "{CALL PROC_INS_SANGRIA(?, ?, ?, ?, ?, ?)}";


                        try (
                                Connection conexao =
                                        Conexao.conectar();

                                CallableStatement comando =
                                        conexao.prepareCall(sql)
                        ) {

                            comando.setInt(
                                    1,
                                    Integer.parseInt(
                                            txtIdSangria.getText()
                                    )
                            );

                            comando.setInt(
                                    2,
                                    idCaixa
                            );

                            comando.setInt(
                                    3,
                                    idFun
                            );

                            comando.setInt(
                                    4,
                                    idSupervisor
                            );

                            comando.setBigDecimal(
                                    5,
                                    lerValor(txtDinheiro)
                            );

                            comando.setBigDecimal(
                                    6,
                                    lerValor(txtSangria)
                            );


                            comando.executeUpdate();


                            JOptionPane.showMessageDialog(
                                    null,
                                    "Sangria inserida com sucesso!"
                            );


                            consultarSangria();


                        } catch (NumberFormatException erro) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Verifique os valores informados."
                            );

                        } catch (SQLException erro) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Erro ao inserir: "
                                            + erro.getMessage()
                            );
                        }
                    }
                });


        // ===============================
        // CONSULTAR
        // ===============================

        btnConsultar.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent evento
                    ) {

                        consultarSangria();
                    }
                });


        // ===============================
        // ALTERAR
        // ===============================

        btnAlterar.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent evento
                    ) {

                        if (idSupervisor == null) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Funcionario sem supervisor."
                            );

                            return;
                        }


                        String sql =
                                "{CALL PROC_ALT_SANGRIA(?, ?, ?, ?, ?, ?)}";


                        try (
                                Connection conexao =
                                        Conexao.conectar();

                                CallableStatement comando =
                                        conexao.prepareCall(sql)
                        ) {


                            comando.setInt(
                                    1,
                                    Integer.parseInt(
                                            txtIdSangria.getText()
                                    )
                            );

                            comando.setInt(
                                    2,
                                    idCaixa
                            );

                            comando.setInt(
                                    3,
                                    idFun
                            );

                            comando.setInt(
                                    4,
                                    idSupervisor
                            );

                            comando.setBigDecimal(
                                    5,
                                    lerValor(txtDinheiro)
                            );

                            comando.setBigDecimal(
                                    6,
                                    lerValor(txtSangria)
                            );


                            comando.executeUpdate();


                            JOptionPane.showMessageDialog(
                                    null,
                                    "Sangria alterada com sucesso!"
                            );


                            consultarSangria();


                        } catch (NumberFormatException erro) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Verifique os valores."
                            );

                        } catch (SQLException erro) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Erro ao alterar: "
                                            + erro.getMessage()
                            );
                        }
                    }
                });


        // ===============================
        // REMOVER
        // ===============================

        btnRemover.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent evento
                    ) {


                        int confirmacao =
                                JOptionPane.showConfirmDialog(
                                        null,
                                        "Deseja remover esta sangria?",
                                        "Confirmar",
                                        JOptionPane.YES_NO_OPTION
                                );


                        if (
                                confirmacao
                                        != JOptionPane.YES_OPTION
                        ) {

                            return;
                        }


                        String sql =
                                "{CALL PROC_DEL_SANGRIA(?)}";


                        try (
                                Connection conexao =
                                        Conexao.conectar();

                                CallableStatement comando =
                                        conexao.prepareCall(sql)
                        ) {


                            comando.setInt(
                                    1,
                                    Integer.parseInt(
                                            txtIdSangria.getText()
                                    )
                            );


                            comando.executeUpdate();


                            JOptionPane.showMessageDialog(
                                    null,
                                    "Sangria removida!"
                            );


                            txtIdSangria.setText("");
                            txtDinheiro.setText("");
                            txtSangria.setText("");
                            txtDinAtual.setText("");


                        } catch (NumberFormatException erro) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Informe o ID da sangria."
                            );

                        } catch (SQLException erro) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Erro ao remover: "
                                            + erro.getMessage()
                            );
                        }
                    }
                });
    }


    private void consultarSangria() {

        String sql =
                "{CALL PROC_CONS_SANGRIA(?)}";


        try (
                Connection conexao =
                        Conexao.conectar();

                CallableStatement comando =
                        conexao.prepareCall(sql)
        ) {


            comando.setInt(
                    1,
                    Integer.parseInt(
                            txtIdSangria.getText()
                    )
            );


            ResultSet resultado =
                    comando.executeQuery();


            if (resultado.next()) {


                txtDinheiro.setText(
                        resultado
                                .getBigDecimal("Dinheiro")
                                .toString()
                );


                txtSangria.setText(
                        resultado
                                .getBigDecimal("Sangria")
                                .toString()
                );


                txtDinAtual.setText(
                        resultado
                                .getBigDecimal("Din_Atual")
                                .toString()
                );


                String funcionario =
                        resultado.getString(
                                "Funcionario"
                        );

                String supervisor =
                        resultado.getString(
                                "Supervisor"
                        );

                String caixa =
                        resultado.getString(
                                "nome_caixa"
                        );


                JOptionPane.showMessageDialog(
                        null,
                        "Funcionario: "
                                + funcionario
                                + "\nSupervisor: "
                                + supervisor
                                + "\nCaixa: "
                                + caixa
                );


            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Sangria nao encontrada."
                );
            }


            resultado.close();


        } catch (NumberFormatException erro) {

            JOptionPane.showMessageDialog(
                    null,
                    "Informe o ID da sangria."
            );

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(
                    null,
                    "Erro ao consultar: "
                            + erro.getMessage()
            );
        }
    }
}