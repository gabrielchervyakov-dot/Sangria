
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class TelaSangria extends JFrame {

    private JLabel lblCaixa_id;
    private JLabel lblCaixa_num;
    private JLabel lblOperador;
    private JLabel lblSupervisor;
    private JLabel lblDinheiro;
    private JLabel lblSangria;
    private JLabel lblDin_Atual;

    private JTextField txtCaixa_id;
    private JTextField txtCaixa_num;
    private JTextField txtOperador;
    private JTextField txtSupervisor;
    private JTextField txtDinheiro;
    private JTextField txtSangria;
    private JTextField txtDin_Atual;

    private JButton btnInserir;
    private JButton btnConsultar;
    private JButton btnAlterar;
    private JButton btnRemover;

    private JTable tabela;
    private DefaultTableModel modelo;
    private JScrollPane barraRolagem;

    public TelaSangria() {

        setTitle("Sangria Alta Rotacao - Cadastro");
        setSize(850, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        criarComponentes();
        criarEventos();

        setVisible(true);
    }

    private void criarComponentes() {

        lblCaixa_id = new JLabel("ID do Caixa:");
        lblCaixa_id.setBounds(30, 30, 120, 25);
        add(lblCaixa_id);

        txtCaixa_id = new JTextField();
        txtCaixa_id.setBounds(160, 30, 150, 25);
        add(txtCaixa_id);

        lblCaixa_num = new JLabel("Numero do Caixa:");
        lblCaixa_num.setBounds(30, 70, 120, 25);
        add(lblCaixa_num);

        txtCaixa_num = new JTextField();
        txtCaixa_num.setBounds(160, 70, 150, 25);
        add(txtCaixa_num);

        lblOperador = new JLabel("Operador:");
        lblOperador.setBounds(30, 110, 120, 25);
        add(lblOperador);

        txtOperador = new JTextField();
        txtOperador.setBounds(160, 110, 250, 25);
        add(txtOperador);

        lblSupervisor = new JLabel("Supervisor:");
        lblSupervisor.setBounds(30, 150, 120, 25);
        add(lblSupervisor);

        txtSupervisor = new JTextField();
        txtSupervisor.setBounds(160, 150, 250, 25);
        add(txtSupervisor);

        lblDinheiro = new JLabel("Dinheiro:");
        lblDinheiro.setBounds(30, 190, 120, 25);
        add(lblDinheiro);

        txtDinheiro = new JTextField();
        txtDinheiro.setBounds(160, 190, 150, 25);
        add(txtDinheiro);

        lblSangria = new JLabel("Sangria:");
        lblSangria.setBounds(30, 230, 120, 25);
        add(lblSangria);

        txtSangria = new JTextField();
        txtSangria.setBounds(160, 230, 150, 25);
        add(txtSangria);

        lblDin_Atual = new JLabel("Dinheiro Atual:");
        lblDin_Atual.setBounds(450, 190, 120, 25);
        add(lblDin_Atual);

        txtDin_Atual = new JTextField();
        txtDin_Atual.setBounds(570, 190, 150, 25);
        txtDin_Atual.setEditable(false);
        add(txtDin_Atual);

        btnInserir = new JButton("Inserir");
        btnInserir.setBounds(30, 290, 150, 30);
        add(btnInserir);

        btnConsultar = new JButton("Consultar");
        btnConsultar.setBounds(200, 290, 150, 30);
        add(btnConsultar);

        btnAlterar = new JButton("Alterar");
        btnAlterar.setBounds(370, 290, 150, 30);
        add(btnAlterar);

        btnRemover = new JButton("Remover");
        btnRemover.setBounds(540, 290, 150, 30);
        add(btnRemover);

        modelo = new DefaultTableModel();

        modelo.addColumn("Caixa ID");
        modelo.addColumn("Caixa Numero");
        modelo.addColumn("Operador");
        modelo.addColumn("Supervisor");
        modelo.addColumn("Dinheiro");
        modelo.addColumn("Sangria");
        modelo.addColumn("Dinheiro Atual");

        tabela = new JTable(modelo);

        barraRolagem = new JScrollPane(tabela);
        barraRolagem.setBounds(30, 350, 770, 180);
        add(barraRolagem);

        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()
                    && tabela.getSelectedRow() != -1) {

                int linha = tabela.getSelectedRow();

                txtCaixa_id.setText(
                        modelo.getValueAt(linha, 0).toString()
                );

                txtCaixa_num.setText(
                        modelo.getValueAt(linha, 1).toString()
                );

                txtOperador.setText(
                        modelo.getValueAt(linha, 2).toString()
                );

                txtSupervisor.setText(
                        modelo.getValueAt(linha, 3).toString()
                );

                txtDinheiro.setText(
                        modelo.getValueAt(linha, 4).toString()
                );

                txtSangria.setText(
                        modelo.getValueAt(linha, 5).toString()
                );

                Object atual = modelo.getValueAt(linha, 6);
                txtDin_Atual.setText(
                        atual == null ? "" : atual.toString()
                );
            }
        });
    }

    private BigDecimal lerValor(JTextField campo) {
        return new BigDecimal(
                campo.getText().trim().replace(",", ".")
        );
    }

    private void criarEventos() {

        // INSERIR
        btnInserir.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                String sql =
                        "INSERT INTO Sangria_Alta_rotacao " +
                                "(caixa_id, Caixa_num, Operador, Supervisor, " +
                                "Dinheiro, Sangria) " +
                                "VALUES (?, ?, ?, ?, ?, ?)";

                try (
                        Connection conexao = Conexao.conectar();
                        PreparedStatement comando =
                                conexao.prepareStatement(sql)
                ) {

                    comando.setInt(
                            1, Integer.parseInt(txtCaixa_id.getText())
                    );

                    comando.setInt(
                            2, Integer.parseInt(txtCaixa_num.getText())
                    );

                    comando.setString(
                            3, txtOperador.getText()
                    );

                    comando.setString(
                            4, txtSupervisor.getText()
                    );

                    comando.setBigDecimal(
                            5, lerValor(txtDinheiro)
                    );

                    comando.setBigDecimal(
                            6, lerValor(txtSangria)
                    );

                    comando.executeUpdate();

                    JOptionPane.showMessageDialog(
                            null, "Registro inserido com sucesso!"
                    );

                    btnConsultar.doClick();

                } catch (NumberFormatException erro) {

                    JOptionPane.showMessageDialog(
                            null, "Verifique os numeros informados."
                    );

                } catch (SQLException erro) {

                    JOptionPane.showMessageDialog(
                            null, "Erro ao inserir: " + erro.getMessage()
                    );
                }
            }
        });

        // CONSULTAR
        btnConsultar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                String sql =
                        "SELECT caixa_id, Caixa_num, Operador, " +
                                "Supervisor, Dinheiro, Sangria, Din_Atual " +
                                "FROM Sangria_Alta_rotacao " +
                                "ORDER BY caixa_id";

                try (
                        Connection conexao = Conexao.conectar();
                        PreparedStatement comando =
                                conexao.prepareStatement(sql);
                        ResultSet resultado = comando.executeQuery()
                ) {

                    modelo.setRowCount(0);

                    while (resultado.next()) {

                        modelo.addRow(new Object[] {

                                resultado.getInt("caixa_id"),
                                resultado.getInt("Caixa_num"),
                                resultado.getString("Operador"),
                                resultado.getString("Supervisor"),
                                resultado.getBigDecimal("Dinheiro"),
                                resultado.getBigDecimal("Sangria"),
                                resultado.getBigDecimal("Din_Atual")
                        });
                    }

                } catch (SQLException erro) {

                    JOptionPane.showMessageDialog(
                            null, "Erro ao consultar: " + erro.getMessage()
                    );
                }
            }
        });

        // ALTERAR
        btnAlterar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                String sql =
                        "UPDATE Sangria_Alta_rotacao SET " +
                                "Caixa_num = ?, Operador = ?, Supervisor = ?, " +
                                "Dinheiro = ?, Sangria = ? " +
                                "WHERE caixa_id = ?";

                try (
                        Connection conexao = Conexao.conectar();
                        PreparedStatement comando =
                                conexao.prepareStatement(sql)
                ) {

                    comando.setInt(
                            1, Integer.parseInt(txtCaixa_num.getText())
                    );

                    comando.setString(
                            2, txtOperador.getText()
                    );

                    comando.setString(
                            3, txtSupervisor.getText()
                    );

                    comando.setBigDecimal(
                            4, lerValor(txtDinheiro)
                    );

                    comando.setBigDecimal(
                            5, lerValor(txtSangria)
                    );

                    comando.setInt(
                            6, Integer.parseInt(txtCaixa_id.getText())
                    );

                    int linhasAfetadas = comando.executeUpdate();

                    if (linhasAfetadas > 0) {

                        JOptionPane.showMessageDialog(
                                null, "Registro alterado com sucesso!"
                        );

                    } else {

                        JOptionPane.showMessageDialog(
                                null, "Nenhum registro encontrado."
                        );
                    }

                    btnConsultar.doClick();

                } catch (NumberFormatException erro) {

                    JOptionPane.showMessageDialog(
                            null, "Verifique os valores informados."
                    );

                } catch (SQLException erro) {

                    JOptionPane.showMessageDialog(
                            null, "Erro ao alterar: " + erro.getMessage()
                    );
                }
            }
        });

        // REMOVER
        btnRemover.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                String sql =
                        "DELETE FROM Sangria_Alta_rotacao " +
                                "WHERE caixa_id = ?";

                try (
                        Connection conexao = Conexao.conectar();
                        PreparedStatement comando =
                                conexao.prepareStatement(sql)
                ) {

                    int caixa_id = Integer.parseInt(
                            txtCaixa_id.getText()
                    );

                    comando.setInt(1, caixa_id);

                    int confirmacao =
                            JOptionPane.showConfirmDialog(
                                    null,
                                    "Deseja remover este registro?",
                                    "Confirmar exclusao",
                                    JOptionPane.YES_NO_OPTION
                            );

                    if (confirmacao != JOptionPane.YES_OPTION) {
                        return;
                    }

                    int linhasAfetadas = comando.executeUpdate();

                    if (linhasAfetadas > 0) {

                        JOptionPane.showMessageDialog(
                                null, "Registro removido com sucesso!"
                        );

                    } else {

                        JOptionPane.showMessageDialog(
                                null, "Nenhum registro encontrado."
                        );
                    }

                    btnConsultar.doClick();

                } catch (NumberFormatException erro) {

                    JOptionPane.showMessageDialog(
                            null, "O ID deve ser um numero inteiro."
                    );

                } catch (SQLException erro) {

                    JOptionPane.showMessageDialog(
                            null, "Erro ao remover: " + erro.getMessage()
                    );
                }
            }
        });
    }

    public static void main(String[] args) {
        new TelaSangria();
    }
}
